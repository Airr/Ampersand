option casemap:none

.code

include strdup_strfree.asm
include strconcat.asm

strlen_ proc                    ; rdi=buf -> rax=len (destroys rcx)
    push    rdi
    xor     al, al
    or      rcx, -1
    repnz   scasb
    not     rcx
    dec     rcx
    mov     rax, rcx
    pop     rdi
    ret
strlen_ endp

streq_ proc                     ; rdi=a, rsi=b, rdx=expected_len -> rax=1 if equal else 0
    mov     rcx, rdx
    repe    cmpsb
    jne     @streq_no
    mov     rax, 1
    ret
    @streq_no:
        xor     rax, rax
        ret
streq_ endp

fail_exit proc                  ; rsi/rdx = msg/len already set
    mov     rdi, 1
    mov     rax, 1
    syscall
    mov     rax, 60
    mov     rdi, 1
    syscall
fail_exit endp

print_result proc uses rbx      ; rsi=label, rdx=label_len, rdi=NUL-terminated string to print
    mov     rbx, rdi            ; save string ptr (write syscall will use rdi as fd arg)
    mov     rdi, 1
    mov     rax, 1
    syscall                     ; print label

    mov     rdi, rbx
    call    strlen_
    mov     rdx, rax
    mov     rsi, rbx
    mov     rdi, 1
    mov     rax, 1
    syscall                     ; print the string itself

    lea     rsi, nl
    mov     rdx, 1
    mov     rdi, 1
    mov     rax, 1
    syscall                     ; print trailing newline
    ret
print_result endp

main proc
    sub     rsp, 40

    ; ===== Test 1: "Hello" + ", " + "World" + "!" = "Hello, World!" =====
    invoke  strconcat, addr arr1
    test    rax, rax
    jz      f1
    mov     rbx, rax
    lea     rsi, lbl1
    mov     rdx, lbl1_len
    mov     rdi, rbx
    call    print_result
    mov     rdi, rbx
    call    strlen_
    cmp     rax, t1_expect_len
    jne     f1
    mov     rdi, rbx
    lea     rsi, t1_expect
    mov     rdx, t1_expect_len
    call    streq_
    test    rax, rax
    jz      f1
    invoke  strfree, rbx        ; results from strconcat must free via the same strfree
    test    rax, rax
    jnz     f1
    jmp     ok1
f1: lea     rsi, m1
    mov     rdx, m1_len
    call    fail_exit
ok1:

    ; ===== Test 2: empty array (first entry NULL) -> non-NULL "" =====
    invoke  strconcat, addr arr2
    test    rax, rax
    jz      f2
    mov     rbx, rax
    lea     rsi, lbl2
    mov     rdx, lbl2_len
    mov     rdi, rbx
    call    print_result
    mov     rdi, rbx
    call    strlen_
    test    rax, rax
    jnz     f2
    invoke  strfree, rbx
    test    rax, rax
    jnz     f2
    jmp     ok2
f2: lea     rsi, m2
    mov     rdx, m2_len
    call    fail_exit
ok2:

    ; ===== Test 3: empty entries mixed in: "" + "abc" + "" + "def" = "abcdef" =====
    invoke  strconcat, addr arr3
    test    rax, rax
    jz      f3
    mov     rbx, rax
    lea     rsi, lbl3
    mov     rdx, lbl3_len
    mov     rdi, rbx
    call    print_result
    mov     rdi, rbx
    call    strlen_
    cmp     rax, t3_expect_len
    jne     f3
    mov     rdi, rbx
    lea     rsi, t3_expect
    mov     rdx, t3_expect_len
    call    streq_
    test    rax, rax
    jz      f3
    invoke  strfree, rbx
    test    rax, rax
    jnz     f3
    jmp     ok3
f3: lea     rsi, m3
    mov     rdx, m3_len
    call    fail_exit
ok3:

    ; ===== Test 4: many chunks summing past a 4KB page boundary =====
    invoke  strconcat, addr arr4
    test    rax, rax
    jz      f4
    mov     rbx, rax
    lea     rsi, lbl4
    mov     rdx, lbl4_len
    mov     rdi, rbx
    call    print_result
    mov     rdi, rbx
    call    strlen_
    cmp     rax, t4_expect_len
    jne     f4
    ; spot-check: first byte and last byte of the joined buffer
    cmp     byte ptr [rbx], 41h              ; 'A' (chunk1 starts with A's)
    jne     f4
    mov     rdi, rbx
    add     rdi, t4_expect_len
    sub     rdi, 1
    cmp     byte ptr [rdi], 43h              ; 'C' (chunk3 ends with C's)
    jne     f4
    invoke  strfree, rbx
    test    rax, rax
    jnz     f4
    jmp     ok4
f4: lea     rsi, m4
    mov     rdx, m4_len
    call    fail_exit
ok4:

    lea     rsi, pass_msg
    mov     rdx, pass_len
    mov     rdi, 1
    mov     rax, 1
    syscall
    mov     rax, 60
    xor     rdi, rdi
    syscall
main endp

.data
nl      db 10
lbl1     db "Test 1 result: "
lbl1_len equ $ - lbl1
lbl2     db "Test 2 result: (empty string) "
lbl2_len equ $ - lbl2
lbl3     db "Test 3 result: "
lbl3_len equ $ - lbl3
lbl4     db "Test 4 result: "
lbl4_len equ $ - lbl4

; --- test 1 ---
p1a     db "Hello", 0
p1b     db ", ", 0
p1c     db "World", 0
p1d     db "!", 0
arr1    dq offset p1a, offset p1b, offset p1c, offset p1d, 0
t1_expect     db "Hello, World!"
t1_expect_len equ $ - t1_expect

; --- test 2 ---
arr2    dq 0

; --- test 3 ---
p3empty1 db 0
p3a      db "abc", 0
p3empty2 db 0
p3b      db "def", 0
arr3     dq offset p3empty1, offset p3a, offset p3empty2, offset p3b, 0
t3_expect     db "abcdef"
t3_expect_len equ $ - t3_expect

; --- test 4: 3 chunks of 1500 'A'/'B'/'C' = 4500 bytes total, crosses one 4KB page ---
p4a     db 1500 dup ("A"), 0
p4b     db 1500 dup ("B"), 0
p4c     db 1500 dup ("C"), 0
arr4    dq offset p4a, offset p4b, offset p4c, 0
t4_expect_len equ 4500

m1      db "FAIL: test 1 (basic multi-string concat)", 10
m1_len  equ $ - m1
m2      db "FAIL: test 2 (empty array)", 10
m2_len  equ $ - m2
m3      db "FAIL: test 3 (empty entries mixed in)", 10
m3_len  equ $ - m3
m4      db "FAIL: test 4 (page-crossing concat)", 10
m4_len  equ $ - m4
pass_msg db "PASS: all strconcat tests OK", 10
pass_len equ $ - pass_msg

end main
