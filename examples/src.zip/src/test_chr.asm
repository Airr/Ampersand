include amp.inc

.data

.code

main proc argc:dword, argv:ptr
    local number:qword

    mov number, CHR("A")    ; convert the character, assigning to 'number' variable
    PRINT("'A' ASCII Code: '%d'\n", number)

    EXIT(0)                     ; cleanly exit program
main endp

end