include amp.inc


.data


.code

main proc argc:dword, argv:ptr
    local text_dup:ptr
    local custom_buf:ptr

    ; 1. Test strdup and strfree pipeline
    mov text_dup, strdup("Initializing tests...\n")
    puts(text_dup)
    strfree(text_dup)

    ; 2. Test memalloc, memcpy, and memfree
    mov custom_buf, memalloc(256)

    memcpy(custom_buf, "Hello from memalloc!", 20)

    ; Print and final cleanup
    PRINT("%s\n", custom_buf)

    memfree(custom_buf)     ; Free the custom_buf buffer
    EXIT(0)
main endp

end