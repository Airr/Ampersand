AMP_MAIN = 1

include amp.inc

.data

.code

main proc
    local appStr:ptr, appPathStr:ptr                    ; variables on stack

    ; CLS()                                               ; clear the screen
    mov appStr, APPNAME$()
    mov appPathStr, APPPATH$()

    PRINT("Application Name: %s\n", appStr)
    PRINT("Application Path: %s\n", appPathStr)
    EXIT(0)                                                 
main endp

end    