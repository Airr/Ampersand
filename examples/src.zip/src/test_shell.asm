include amp.inc

.data

.code

; ==============================================================================
; Main Entry Point
; ==============================================================================
main PROC
    local result:qword, track:ptr, cmd:ptr
    mov track, ENC$("/home/riveraa/Music/Top Songs 2000 - 2019/MP3/021 - EminemMusic - The Real Slim Shady.mp3",0)
    mov cmd, CONCAT$("/usr/bin/ffprobe -hide_banner -stats -i ", track)
    ; Call the SHELL procedure passing the command string
    ; storing the return code in 'result'.
    mov result, SHELL(cmd)
    .if result != 0
        PRINT("Error: %d\n", result)
        EXIT(result)
    .endif
    
    
    ; If execve succeeds, we fall through here. Exit cleanly.
    EXIT(0)
main ENDP

end