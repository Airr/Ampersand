include amp.inc

.data

.code

main proc argc:dword, argv:ptr
    local str1:ptr, str2:ptr, tmpStr:ptr, answer:ptr, len:qword

    cls()
    assign answer, input, "Enter Your Name: "

    .if (strlen(answer) > 1)
        assign tmpStr, strcat, "You Entered: ", answer
        puts( tmpStr )
        strfree(tmpStr)
        epause()
    .endif

    cls()    
    puts("------------------------------\n")
    puts("-- Testing string functions --\n")
    puts("------------------------------\n\n")



    assign str1, strdup, "Hello, World!"
    assign len, strlen, str1
    assign str2, itoa, len

    puts( "Original String:\t" )
    puts(str1)
    puts("\n")

    puts("Original String Len:\t")
    puts(str2)
    puts("\n")

    puts("Uppercase String:\t")
    strupr(str1)
    puts(str1)
    puts("\n")

    puts("Lowercase String:\t")
    strlwr(str1)
    puts(str1)
    puts("\n")

    puts("Reversed String:\t")
    strrev(str1)
    puts(str1)
    puts("\n")


    strfree(str1)

    exit(0)
main endp


end
