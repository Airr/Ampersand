include amp.inc

.data

.code

main proc argc:dword, argv:ptr
    local fSize:qword, fSizeStr:ptr, exeName:ptr, msg:ptr

    CLS()                           ; clear the screen
    mov exeName, APPNAME$()
    mov fSize, LOF(exeName)

    PRINT("'%s': File Size = %d bytes\n", exeName, fSize)



    EXIT(0)                         ; cleanly exit program
main endp

end