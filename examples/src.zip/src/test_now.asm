include amp.inc

.data


.code

main proc uses rbx
    local result:ptr

    CLS()
    mov result, NOW$()
    PRINT("Current Date/Time: %s\n", result)

    EXIT(0)                         
main endp

end